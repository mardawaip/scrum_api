<?php
//$conn = new PDO('mysql:host=localhost;dbname=bplhkotabogor','root','');
$conn = new PDO('mysql:host=localhost;dbname=devbplhk_db','root','');
$path = 'http://localhost/developbplhkotabogor/uploads/ragamdata/';

?>